import { DurationsPipe } from './durations.pipe';

describe('DurationsPipe', () => {
  it('create an instance', () => {
    const pipe = new DurationsPipe();
    expect(pipe).toBeTruthy();
  });
});
